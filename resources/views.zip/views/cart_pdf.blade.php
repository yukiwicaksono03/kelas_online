
<center>
    <h1>PROPOSAL</h1>

                                    <table width="100%">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>Kategori</th>
                                                <th>Item</th>
                                                <th>Detail</th>
                                                <!-- <th>Fungsi</th> -->
                                            </tr>
                                        </thead>
                                        <tbody>
                                            
                                            @php
                                                $no = 1;
                                            @endphp
                                            @foreach($billing as $item)
                                            
                                            <tr>
                                                <td align="center">{{$no++}}</td>
                                                <td align="center">
                                                    <h6>
                                                        @if($item->sub_kategori == 1)
                                                        Dekorasi
                                                        @elseif($item->sub_kategori == 2)
                                                        Attire
                                                        @elseif($item->sub_kategori == 3)
                                                        MUA
                                                        @elseif($item->sub_kategori == 4)
                                                        Photo & Video
                                                        @elseif($item->sub_kategori == 5)
                                                        Musik
                                                        @elseif($item->sub_kategori == 6)
                                                        Catering
                                                        @else
                                                        -
                                                        @endif
                                                    </h6>
                                                </td>
                                                <td align="center">
                                                    <div>
                                                        <div>
                                                            <div>
                                                                <!-- <img src="assets/imgs/team/2.jpg" width="100px"> -->
                                                                <!-- <img src="{{ asset('images/') }}/{{$item->lokasi}}" alt=""> -->
                                                            </div>
                                                        </div>
                                                        <div>
                                                            <h6>{{$item->nama}}</h6>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td>
                                                    <h5><pre>{{$item->deskripsi}}</pre></h5>
                                                </td>
                                                <!-- <td>
                                                    <a href="#" onclick="return edit({{$item->sub_kategori}}, {{$item->id}});">
                                                        <span></span>
                                                    </a>
                                                    <a href="#" onclick="return del({{$item->id}});">
                                                        <span></span>
                                                    </a>
                                                </td> -->
                                            </tr>

                                            @endforeach

                                            </tbody>
                                    </table>
</center>