@extends('layout')
@section('content')



<script type="text/javascript">

function send_proposal(){
                
    var nama = $("#nama").val(); //nama
    var phone = $("#phone").val(); //phone
    var email = $("#email").val(); //email
    var alamat = $("#alamat").val(); //alamat
    // var list_item = $("#list_item").val();
    // var list_item_json = $("#list_item_json").val();
    // // var token = $('input[name="_token"]').val();

    if(!nama){
        alert('Mohon masukkan Nama !');
        return false;
        $("#nama").focus();
    }
    if(!phone){
        alert('Mohon masukkan No. Handphone !');
        return false;
        $("#phone").focus();
    }
    if(!email){
        alert('Mohon masukkan Email !');
        return false;
        $("#email").focus();
    }
    if(!alamat){
        alert('Mohon isi Alamat !');
        return false;
        $("#alamat").focus();
    }

    // var parts = input1.split("/");
    // var formattedDate = `${parts[2]}-${parts[0]}-${parts[1]}`;


      if (confirm("Yakin dengan proposal anda ?") == true) {
        location.replace("/generate_pdf");
        $.post("/save_proposal",
        {
          // token: token,
            "_token": "{{ csrf_token() }}",
            nama : nama,
            phone : phone,
            email : email,
            alamat : alamat
            // notes : list_item,
            // jml_org : input3,
            // tgl_booking : formattedDate+' '+input2,
            // tipe_order : 'resto',
            // "data_json": list_item_json
        },
        function(data,status){
            // alert(data);
            
            if(data == 't'){
                // alert('Proposal berhasil disubmit. \nSilahkan tunggu informasi dari admin.');
                location.replace("/berhasil");
            }
          // alert("Data: " + data + "\nStatus: " + status);
        });
        return false;
      } else {
        return false;
      }

}
</script>

            <main class="main-bg">

                <!-- ==================== Start Slider ==================== -->

                <header class="work-header section-padding pb-0">
                    <div class="container mt-80">
                        <div class="row">
                            <div class="col-12">
                                <div class="caption">
                                    <h6 class="sub-title">Shopping</h6>
                                    <h1>checkout.</h1>
                                </div>
                            </div>
                        </div>
                    </div>
                </header>

                <!-- ==================== End Slider ==================== -->



                <!-- ==================== Start cart ==================== -->

                <section class="shop-checkout section-padding">
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="order-form">
                                    <h4 class="mb-40">Billing Details</h4>
                                    <form action="contact.php">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="">Nama Lengkap *</label>
                                                    <input type="text" name="nama" id="nama" required>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="">No. Handphone *</label>
                                                    <input type="text" name="phone" id="phone" required>
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <div class="form-group">
                                                    <label for="">Email *</label>
                                                    <input type="email" name="email" id="email" required>
                                                </div>
                                            </div>
                                            <!-- <div class="col-12">
                                                <div class="form-group">
                                                    <label for="">Country *</label>
                                                    <input type="text" name="country" required>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label for="">City / Town *</label>
                                                    <input type="text" name="city" required>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label for="">Area *</label>
                                                    <input type="text" name="area" required>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group">
                                                    <label for="">Postal Code *</label>
                                                    <input type="text" name="postal_code" required>
                                                </div>
                                            </div>-->
                                            <div class="col-12">
                                                <div class="form-group">
                                                    <label for="">Alamat *</label>
                                                    <input type="text" name="alamat" id="alamat" required>
                                                </div>
                                            </div>
                                            <!-- <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="">Kota</label>
                                                    <input type="text" name="company_name">
                                                </div>
                                            </div> -->
                                        </div>
                                    </form>
                                </div>
                            </div>
                            <div class="col-lg-5 offset-lg-1">
                                <div class="checkout-order-info">
                                    <h4 class="mb-40">Your Order</h4>
                                    <div>
                                        <ul class="rest">
                                            @foreach($billing as $item)
                                            <li class="mb-5">
                                                <div class="d-flex align-items-center">
                                                    <div>
                                                        <img style="width: 80px;" src="{{ asset('images/') }}/{{$item->lokasi}}" alt="Gallery Image">
                                                        <!-- <p>{{$item->lokasi}}</p> -->
                                                    </div>
                                                    <div class="ml-auto" align="left" style="margin-left: 20px;">
                                                        <h5 class="fz-18">{{$item->nama}}</h5>
                                                    </div>
                                                </div>
                                            </li>
                                            @endforeach
                                        </ul>
                                        <div class="text mt-40">
                                            <p>Your personal data will be used to process your order, support your experience throughout this website, and for other purposes described in our <a href="#0">privacy policy</a>.</p>
                                        </div>
                                        <div class="mt-30">
                                            <button onclick="send_proposal();" class="butn butn-md butn-bg main-colorbg4 text-dark">
                                                <span class="text-u fw-600">Submit Proposal</span>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

                <!-- ==================== End cart ==================== -->


            </main>
@endsection