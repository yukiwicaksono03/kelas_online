@extends('layout')
@section('content')




    <main class="main-bg position-re">


        <!-- ==================== Start Slider ==================== -->

        <header class="slider slider-prlx o-hidden">
            <!-- <div class="lines two"></div> -->
            <div class="swiper-container parallax-slider">
                <div class="swiper-wrapper">
                    <div class="swiper-slide">
                        <div class="bg-img valign" data-background="assets/imgs/background/17.jpg" data-overlay-dark="1">
                            <div class="container">
                                <div class="row justify-content-center">
                                    <div class="col-lg-10">
                                        <div class="caption text-center">
                                            <h6 class="sub-title mb-15">
                                                <svg width="18" height="18" viewBox="0 0 18 18" fill="none"
                                                    xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M13.922 4.5V11.8125C13.922 11.9244 13.8776 12.0317 13.7985 12.1108C13.7193 12.1899 13.612 12.2344 13.5002 12.2344C13.3883 12.2344 13.281 12.1899 13.2018 12.1108C13.1227 12.0317 13.0783 11.9244 13.0783 11.8125V5.51953L4.79547 13.7953C4.71715 13.8736 4.61092 13.9176 4.50015 13.9176C4.38939 13.9176 4.28316 13.8736 4.20484 13.7953C4.12652 13.717 4.08252 13.6108 4.08252 13.5C4.08252 13.3892 4.12652 13.283 4.20484 13.2047L12.4806 4.92188H6.18765C6.07577 4.92188 5.96846 4.87743 5.88934 4.79831C5.81023 4.71919 5.76578 4.61189 5.76578 4.5C5.76578 4.38811 5.81023 4.28081 5.88934 4.20169C5.96846 4.12257 6.07577 4.07813 6.18765 4.07812H13.5002C13.612 4.07813 13.7193 4.12257 13.7985 4.20169C13.8776 4.28081 13.922 4.38811 13.922 4.5Z"
                                                        fill="currentColor"></path>
                                                </svg>
                                                <span class="ml-10">Creative Agency</span>
                                            </h6>
                                            <h1 class="fz-60">Providing Best Digital Solutions & Grow Business.</h1>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="bg-img valign" data-background="assets/imgs/background/2.jpg"
                            data-overlay-dark="7">
                            <div class="container">
                                <div class="row justify-content-center">
                                    <div class="col-lg-10">
                                        <div class="caption text-center">
                                            <h6 class="sub-title mb-15">
                                                <svg width="18" height="18" viewBox="0 0 18 18" fill="none"
                                                    xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M13.922 4.5V11.8125C13.922 11.9244 13.8776 12.0317 13.7985 12.1108C13.7193 12.1899 13.612 12.2344 13.5002 12.2344C13.3883 12.2344 13.281 12.1899 13.2018 12.1108C13.1227 12.0317 13.0783 11.9244 13.0783 11.8125V5.51953L4.79547 13.7953C4.71715 13.8736 4.61092 13.9176 4.50015 13.9176C4.38939 13.9176 4.28316 13.8736 4.20484 13.7953C4.12652 13.717 4.08252 13.6108 4.08252 13.5C4.08252 13.3892 4.12652 13.283 4.20484 13.2047L12.4806 4.92188H6.18765C6.07577 4.92188 5.96846 4.87743 5.88934 4.79831C5.81023 4.71919 5.76578 4.61189 5.76578 4.5C5.76578 4.38811 5.81023 4.28081 5.88934 4.20169C5.96846 4.12257 6.07577 4.07813 6.18765 4.07812H13.5002C13.612 4.07813 13.7193 4.12257 13.7985 4.20169C13.8776 4.28081 13.922 4.38811 13.922 4.5Z"
                                                        fill="currentColor"></path>
                                                </svg>
                                                <span class="ml-10">Creative Agency</span>
                                            </h6>
                                            <h1 class="fz-60">Providing Best Digital Solutions & Grow Business.</h1>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="bg-img valign" data-background="assets/imgs/background/22.jpg"
                            data-overlay-dark="1">
                            <div class="container">
                                <div class="row justify-content-center">
                                    <div class="col-lg-10">
                                        <div class="caption text-center">
                                            <h6 class="sub-title mb-15">
                                                <svg width="18" height="18" viewBox="0 0 18 18" fill="none"
                                                    xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M13.922 4.5V11.8125C13.922 11.9244 13.8776 12.0317 13.7985 12.1108C13.7193 12.1899 13.612 12.2344 13.5002 12.2344C13.3883 12.2344 13.281 12.1899 13.2018 12.1108C13.1227 12.0317 13.0783 11.9244 13.0783 11.8125V5.51953L4.79547 13.7953C4.71715 13.8736 4.61092 13.9176 4.50015 13.9176C4.38939 13.9176 4.28316 13.8736 4.20484 13.7953C4.12652 13.717 4.08252 13.6108 4.08252 13.5C4.08252 13.3892 4.12652 13.283 4.20484 13.2047L12.4806 4.92188H6.18765C6.07577 4.92188 5.96846 4.87743 5.88934 4.79831C5.81023 4.71919 5.76578 4.61189 5.76578 4.5C5.76578 4.38811 5.81023 4.28081 5.88934 4.20169C5.96846 4.12257 6.07577 4.07813 6.18765 4.07812H13.5002C13.612 4.07813 13.7193 4.12257 13.7985 4.20169C13.8776 4.28081 13.922 4.38811 13.922 4.5Z"
                                                        fill="currentColor"></path>
                                                </svg>
                                                <span class="ml-10">Creative Agency</span>
                                            </h6>
                                            <h1 class="fz-60">Providing Best Digital Solutions & Grow Business.</h1>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </header>

        <!-- ==================== End Slider ==================== -->



        <!-- ==================== Start intro ==================== -->
        <section class="portfolio section-padding">
            <div class="container ontop">
                <div class="sec-lg-head mb-80">
                    <div class="row">
                        <div class="col-lg-8">
                            <div class="position-re">
                                <h6 class="dot-titl mb-10">Selected Projects</h6>
                                <h2 class="fz-70 fw-700">Our Colaboration</h2>
                            </div>
                            <div class="underline">
                                <!-- <a href="Kolaborasi.html" class="mt-30 ls1 sub-title">Read More <i class="ml-5">
                                        <svg width="18" height="18" viewBox="0 0 18 18" fill="none"
                                            xmlns="http://www.w3.org/2000/svg">
                                            <path
                                                d="M13.922 4.5V11.8125C13.922 11.9244 13.8776 12.0317 13.7985 12.1108C13.7193 12.1899 13.612 12.2344 13.5002 12.2344C13.3883 12.2344 13.281 12.1899 13.2018 12.1108C13.1227 12.0317 13.0783 11.9244 13.0783 11.8125V5.51953L4.79547 13.7953C4.71715 13.8736 4.61092 13.9176 4.50015 13.9176C4.38939 13.9176 4.28316 13.8736 4.20484 13.7953C4.12652 13.717 4.08252 13.6108 4.08252 13.5C4.08252 13.3892 4.12652 13.283 4.20484 13.2047L12.4806 4.92188H6.18765C6.07577 4.92188 5.96846 4.87743 5.88934 4.79831C5.81023 4.71919 5.76578 4.61189 5.76578 4.5C5.76578 4.38811 5.81023 4.28081 5.88934 4.20169C5.96846 4.12257 6.07577 4.07813 6.18765 4.07812H13.5002C13.612 4.07813 13.7193 4.12257 13.7985 4.20169C13.8776 4.28081 13.922 4.38811 13.922 4.5Z"
                                                fill="currentColor"></path>
                                        </svg></i>
                                </a> -->
                            </div>
                        </div>
                        <div class="col-lg-4 d-flex align-items-center">
                            <div class="text">
                                <p>Nemo enim ipsam voluptatem quia voluptas sit odit aut fugit, sed quia.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="gallery">

                    <div class="row grid md-marg">

                        @foreach($gambar as $item)
                        <div class="col-lg-4 col-md-6 items web info-overlay mb-50">
                            <div class="item-img o-hidden">
                                <a href="/detail_kategori/{{$item->kategori}}" class="imago wow">
                                    <div class="inner wow">
                                        <img src="{{ asset('images/') }}/{{$item->lokasi}}" alt="image">
                                    </div>
                                </a>
                                <div class="info">
                                    <span class="mb-15">
                                        <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                            <path d="M13.922 4.5V11.8125C13.922 11.9244 13.8776 12.0317 13.7985 12.1108C13.7193 12.1899 13.612 12.2344 13.5002 12.2344C13.3883 12.2344 13.281 12.1899 13.2018 12.1108C13.1227 12.0317 13.0783 11.9244 13.0783 11.8125V5.51953L4.79547 13.7953C4.71715 13.8736 4.61092 13.9176 4.50015 13.9176C4.38939 13.9176 4.28316 13.8736 4.20484 13.7953C4.12652 13.717 4.08252 13.6108 4.08252 13.5C4.08252 13.3892 4.12652 13.283 4.20484 13.2047L12.4806 4.92188H6.18765C6.07577 4.92188 5.96846 4.87743 5.88934 4.79831C5.81023 4.71919 5.76578 4.61189 5.76578 4.5C5.76578 4.38811 5.81023 4.28081 5.88934 4.20169C5.96846 4.12257 6.07577 4.07813 6.18765 4.07812H13.5002C13.612 4.07813 13.7193 4.12257 13.7985 4.20169C13.8776 4.28081 13.922 4.38811 13.922 4.5Z" fill="currentColor"></path>
                                        </svg>
                                    </span>
                                    <h6 class="sub-title tag"><a href="#" style="font-weight: bold;"> List Item <br></a></h6>
                                    <!-- <h6 class="sub-title tag"><a href=""> itemku <br> makeup <br> barang lain</a></h6> -->
                                    <h5><a href="/detail_kategori/{{$item->kategori}}">{{$item->nama}}</a></h5>
                                </div>
                            </div>
                        </div>
                        @endforeach


                    </div>

                </div>
            </div>
        </section>
        <section class="about section-padding main-bg">
            <div class="container ontop">
                <div class="row">
                    <div class="col-lg-5 valign">
                        <div class="about-circle-crev md-hide">
                            <div class="circle-button">
                                <div class="rotate-circle fz-16 ls1 text-u">
                                    <svg class="textcircle" viewBox="0 0 500 500">
                                        <defs>
                                            <path id="textcircle"
                                                d="M250,400 a150,150 0 0,1 0,-300a150,150 0 0,1 0,300Z">
                                            </path>
                                        </defs>
                                        <text>
                                            <textPath xlink:href="#textcircle" textLength="900"> Creative Wedding
                                                Place - Creative Wedding Place - </textPath>
                                        </text>
                                    </svg>
                                </div>
                            </div>
                            <div class="half-circle-img">
                                <img src="assets/imgs/about/1.jpg" alt="">
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-7 valign">
                        <div class="cont sec-lg-head">
                            <h6 class="dot-titl mb-20">About Agency</h6>
                            <h2 class="d-slideup wow">
                                <span class="sideup-text"><span class="up-text">We’re the place to plan </span></span>
                                <span class="sideup-text"><span class="up-text">your wedding ease</span></span>
                            </h2>
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="text mt-20">
                                        <p>Making us the ultimate destination for turning 
                                            your dream wedding into a reality.</p>
                                    </div>
                                    <div class="underline">
                                        <a href="About.html" class="mt-30 ls1 sub-title">Read More <i class="ml-5">
                                                <svg width="18" height="18" viewBox="0 0 18 18" fill="none"
                                                    xmlns="http://www.w3.org/2000/svg">
                                                    <path
                                                        d="M13.922 4.5V11.8125C13.922 11.9244 13.8776 12.0317 13.7985 12.1108C13.7193 12.1899 13.612 12.2344 13.5002 12.2344C13.3883 12.2344 13.281 12.1899 13.2018 12.1108C13.1227 12.0317 13.0783 11.9244 13.0783 11.8125V5.51953L4.79547 13.7953C4.71715 13.8736 4.61092 13.9176 4.50015 13.9176C4.38939 13.9176 4.28316 13.8736 4.20484 13.7953C4.12652 13.717 4.08252 13.6108 4.08252 13.5C4.08252 13.3892 4.12652 13.283 4.20484 13.2047L12.4806 4.92188H6.18765C6.07577 4.92188 5.96846 4.87743 5.88934 4.79831C5.81023 4.71919 5.76578 4.61189 5.76578 4.5C5.76578 4.38811 5.81023 4.28081 5.88934 4.20169C5.96846 4.12257 6.07577 4.07813 6.18765 4.07812H13.5002C13.612 4.07813 13.7193 4.12257 13.7985 4.20169C13.8776 4.28081 13.922 4.38811 13.922 4.5Z"
                                                        fill="currentColor"></path>
                                                </svg></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row md-marg mt-100 justify-content-center">
                    <div class="col-lg-4 col-md-6">
                        <div class="item-serv md-mb50">
                            <div class="d-flex align-items-center pb-20 mb-30 bord-thin-bottom">
                                <div class="mr-30">
                                    <div class="icon-img-50">
                                        <img src="assets/imgs/serv-icons/0.png" alt="">
                                    </div>
                                </div>
                                <div>
                                    <h6>Digital Wedding Plant</h6>
                                </div>
                            </div>
                            <p class="fz-14">new ways to showcase user content on digital support and envisioning the
                                future arts.</p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="item-serv md-mb50">
                            <div class="d-flex align-items-center pb-20 mb-30 bord-thin-bottom">
                                <div class="mr-30">
                                    <div class="icon-img-50">
                                        <img src="assets/imgs/serv-icons/1.png" alt="">
                                    </div>
                                </div>
                                <div>
                                    <h6>Feel Free To Choose</h6>
                                </div>
                            </div>
                            <p class="fz-14">new ways to showcase user content on digital support and envisioning the
                                future arts.</p>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="item-serv">
                            <div class="d-flex align-items-center pb-20 mb-30 bord-thin-bottom">
                                <div class="mr-30">
                                    <div class="icon-img-50">
                                        <img src="assets/imgs/serv-icons/2.png" alt="">
                                    </div>
                                </div>
                                <div>
                                    <h6>Suit it perfectly to your liking</h6>
                                </div>
                            </div>
                            <p class="fz-14">new ways to showcase user content on digital support and envisioning the
                                future arts.</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- ==================== End intro ==================== -->



        <!-- ==================== Start section image ==================== -->

        <div class="back-image bg-img parallaxie" data-background="assets/imgs/background/17.jpg" data-overlay-dark="5">
        </div>

        <!-- ==================== End section image ==================== -->



        <!-- ==================== Start Team ==================== -->

        <section class="team-box section-padding">
            <div class="container">
                <div class="sec-lg-head mb-80">
                    <div class="row">
                        <div class="col-lg-8">
                            <div class="position-re">
                                <h6 class="dot-titl mb-10">Selected Projects</h6>
                                <h2 class="fz-70 fw-700">Featured Works</h2>
                            </div>
                        </div>
                        <div class="col-lg-4 d-flex align-items-center">
                            <div class="text">
                                <p>Nemo enim ipsam voluptatem quia voluptas sit odit aut fugit, sed quia.</p>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row md-marg">
                    <div class="col-lg-4">
                        <div class="item md-mb50">
                            <div class="img">
                                <img src="assets/imgs/team/1.jpg" alt="">
                            </div>
                            <div class="info d-flex align-items-center">
                                <div>
                                    <div class="circle-50">
                                        <img src="assets/imgs/team/1.jpg" alt="" class="circle-img">
                                    </div>
                                </div>
                                <div class="cont ml-20">
                                    <span class="fz-12 opacity-8">Co-Founder</span>
                                    <h6 class="fz-16">Alfi</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="item md-mb50">
                            <div class="img">
                                <img src="assets/imgs/team/2.jpg" alt="">
                            </div>
                            <div class="info d-flex align-items-center">
                                <div>
                                    <div class="circle-50">
                                        <img src="assets/imgs/team/2.jpg" alt="" class="circle-img">
                                    </div>
                                </div>
                                <div class="cont ml-20">
                                    <span class="fz-12 opacity-8">Co-Founder</span>
                                    <h6 class="fz-16">Alfi</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="item">
                            <div class="img">
                                <img src="assets/imgs/team/3.jpg" alt="">
                            </div>
                            <div class="info d-flex align-items-center">
                                <div>
                                    <div class="circle-50">
                                        <img src="assets/imgs/team/3.jpg" alt="" class="circle-img">
                                    </div>
                                </div>
                                <div class="cont ml-20">
                                    <span class="fz-12 opacity-8">Co-Founder</span>
                                    <h6 class="fz-16">Alfi</h6>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- ==================== End Team ==================== -->




    </main>
@endsection