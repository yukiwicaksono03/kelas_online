@extends('layout')
@section('content')

<center>
<h1>BERHASIL KIRIM PROPOSAL</h1><br>

<button onclick="location.replace('/');" class="butn butn-md butn-bg main-colorbg4 text-dark">
	<span class="text-u fw-600">Lanjut Browsing</span>
</button>

</center>

@endsection

