<!-- resources/views/emails/example.blade.php -->

<!DOCTYPE html>
<html>
<head>
    <title>Email Subject</title>
</head>
<body>
    <h1>Hello, {{ $data['name'] }}</h1>
    <p>This is a sample email content.</p>
</body>
</html>
