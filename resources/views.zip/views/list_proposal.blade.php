@extends('layouts.app')
@section('content')
    <body>
        <div class="container">

            <div class="card mt-5">
                <div class="card-header text-center">
                    <strong>LIST DATA ITEM</strong>
                </div>
                <div class="card-body">
                    <a href="/admin/proposal/tambah" class="btn btn-primary">Input Item Baru</a>
                    <br/>
                    <br/>
                    <table class="table table-bordered table-hover table-striped">
                        <thead>
                            <tr>
                                <th>No</th>
                                <!-- <th>Gambar</th> -->
                                <th>Nama</th>
                                <th>Phone</th>
                                <th>Email</th> 
                                <th>Tanggal Order</th> 
                                <th>Status</th>
                                <th>Fungsi</th>
                            </tr>
                        </thead>
                        <tbody>
                            
                            @php $no = 1; @endphp
                            @foreach($list_proposal as $p)

                            @php
                            $status = '';
                            
                            if($p->status == '1'){
                                $status = 'Approved';
                            }elseif($p->status == '1'){
                                $status = 'Rejected';
                            }else{
                                $status = 'Awaiting';
                            }
                            @endphp

                            <tr>
                                <td>{{ $no }}</td>
                                <!-- <td>
                                    <div class="card mb-2" style="max-width: 200px;">
                                        <img class="img-fluid mb-2" src="{{ url('/images').'/'.$p->lokasi }}">
                                    </div>
                                </td> -->
                                <td>{{ $p->nama }}</td>
                                <td>{{ $p->phone }}</td>
                                <td>{{ $p->email }}</td>
                                <td>{{ $p->trans_date }}</td>
                                <td>{{ $status }}</td>
                                <td>
                                    <a href="/admin/proposal/pdf/{{ $p->lpid }}" class="btn btn-primary">PDF</a>
                                    <!-- <a href="/admin/proposal/edit/{{ $p->gid }}" class="btn btn-warning">Detail</a> -->
                                    <!-- <a href="/admin/proposal/hapus/{{ $p->gid }}" class="btn btn-danger">Hapus</a> -->
                                </td>
                            </tr>
                            @php $no++; @endphp
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </body>
@endsection