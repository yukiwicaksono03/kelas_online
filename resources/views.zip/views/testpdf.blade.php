<div>
    <h1>Hello World</h1>

    <table>
        <tr><td>{{ $foo ?? '' }}</td></tr>
    </table>
    
    <html-separator/>

    <table>
        <tr><td>{{ $bar ?? '' }}</td></tr>
    </table>

    <html-separator/>
</div>